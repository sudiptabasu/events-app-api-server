const MockDatabaseService = require("./class.mock.database.service");
let db;
db = new MockDatabaseService();
module.exports = db;
